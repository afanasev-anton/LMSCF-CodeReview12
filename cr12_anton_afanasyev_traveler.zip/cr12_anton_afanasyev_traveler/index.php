<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_Anton_Afanasyev_traveler
 */

get_header();
?>

	<div id="primary" class="content-area container-fluid">

		<div class="row p-2">

		<?php
		if ( have_posts() ) : 

			/* Start the Loop */
			while ( have_posts() ) : the_post(); ?>

				<div class="col-12 col-sm-6 col-lg-4 p-3">
					<div class="card text-center">
						<?php the_post_thumbnail( 'thumbnail', array('class' => 'card-img-top') ); ?>
		                <div class="card-body">
			                <h3 class="card-title">
			                	<a href="<?php the_permalink() ?>" class="text-dark"><?php the_title(); ?></a>
			                </h3>
			                
			                <p class="text-muted">
			                    Posted by <?php the_author(); ?> on <?php the_time('F j, Y') ?>
			                </p>
			                <p class="card-text"><?php  ?></p>
			            </div>
		            </div>	                
            </div>

				<?php

			endwhile;
		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;?>

		</div>
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
